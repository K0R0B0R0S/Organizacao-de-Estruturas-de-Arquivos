#ifndef __SEARCH_FUNCIONS_H__
#define __SEARCH_FUNCIONS_H__
#include <stdio.h>

int buscaBinaria(FILE *f, char *CEP);

#endif